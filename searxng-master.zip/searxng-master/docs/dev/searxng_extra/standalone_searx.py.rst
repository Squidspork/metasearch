
.. _standalone_searx.py:

=====================================
``searxng_extra/standalone_searx.py``
=====================================

.. automodule:: searxng_extra.standalone_searx
  :members:
