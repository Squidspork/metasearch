===========================
Administrator documentation
===========================

.. toctree::
   :maxdepth: 2
   :caption: Contents

   installation
   installation-searxng
   installation-uwsgi
   installation-nginx
   installation-apache
   installation-docker
   installation-switch2ng
   update-searxng
   engines/index
   api
   architecture
   filtron
   morty
   plugins
   buildhosts
