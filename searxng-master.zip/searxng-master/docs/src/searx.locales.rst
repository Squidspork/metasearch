.. _searx.locales:

=======
Locales
=======

.. automodule:: searx.locales
  :members:
