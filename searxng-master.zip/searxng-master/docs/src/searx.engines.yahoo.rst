.. _yahoo engine:

============
Yahoo Engine
============

.. automodule:: searx.engines.yahoo
  :members:
