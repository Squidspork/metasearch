.. _searx.utils:

=================================
Utility functions for the engines
=================================

.. automodule:: searx.utils
  :members:
