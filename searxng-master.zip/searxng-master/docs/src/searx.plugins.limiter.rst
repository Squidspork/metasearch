.. _limiter plugin:

==============
Limiter Plugin
==============

.. sidebar:: info

   The :ref:`limiter plugin` requires a :ref:`Redis <settings redis>` database.

.. automodule:: searx.plugins.limiter
  :members:

