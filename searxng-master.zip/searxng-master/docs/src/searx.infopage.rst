.. _searx.infopage:

================
Online ``/info``
================

.. automodule:: searx.infopage
  :members:
